
import { GoogleGenAI, Type, Modality } from "@google/genai";

export const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// Main Chat Service
export async function* sendMessageStream(
  message: string, 
  history: any[] = [], 
  customInstructions: string = "", 
  fileData?: { data: string; mimeType: string },
  usePro: boolean = false,
  persona: string = "Warm Companion"
) {
  const ai = getAIClient();
  const modelName = usePro ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
  
  const personaPrompts: Record<string, string> = {
    "Warm Companion": "You are a warm, extremely friendly, and supportive AI friend.",
    "Professional Assistant": "You are a highly efficient, precise, and professional technical assistant.",
    "Creative Spark": "You are a wild, imaginative, and highly creative brainstorming partner."
  };

  const chat = ai.chats.create({
    model: modelName,
    config: {
      systemInstruction: `You are Sclarista AI, a world-class, multi-modal intelligence created by Grycal. ${personaPrompts[persona] || personaPrompts["Warm Companion"]} ${customInstructions}. You MUST speak exclusively in English. Your responses should be helpful, brilliant, and concise. Emojis are encouraged but markdown formatting symbols like asterisks or hashes are strictly forbidden. For code, just provide the raw code text clearly. Always end every response with a thoughtful question. ✨`,
      tools: [{ googleSearch: {} }]
    }
  });

  const parts: any[] = [];
  if (fileData) {
    parts.push({
      inlineData: {
        data: fileData.data,
        mimeType: fileData.mimeType
      }
    });
  }
  parts.push({ text: message });

  const responseStream = await chat.sendMessageStream({ message: parts });
  for await (const chunk of responseStream) {
    yield chunk;
  }
}

// Scene Analysis for counting objects
export async function analyzeScene(base64Image: string) {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType: 'image/jpeg' } },
        { text: "Identify every distinct object in this image. For each object, give its name and the exact count of how many are present. Format the response as a valid JSON object with a key 'items' which is an array of {name: string, count: number} and a key 'description' with a short summary." }
      ]
    },
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          items: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                count: { type: Type.NUMBER }
              },
              required: ['name', 'count']
            }
          },
          description: { type: Type.STRING }
        },
        required: ['items', 'description']
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (e) {
    console.error("JSON Parse Error", e);
    throw new Error("Failed to parse scene data.");
  }
}

// Stable Image Generation
export async function generateAIImage(prompt: string, quality: '1K' | '2K' | '4K' = '1K') {
  const ai = getAIClient();
  const modelName = (quality === '2K' || quality === '4K') ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
  
  const response = await ai.models.generateContent({
    model: modelName,
    contents: { parts: [{ text: prompt }] },
    config: {
      imageConfig: {
        aspectRatio: "1:1",
        ...(modelName === 'gemini-3-pro-image-preview' ? { imageSize: quality } : {})
      }
    }
  });

  if (!response.candidates?.[0]?.content?.parts) throw new Error("No response from AI");

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  throw new Error("No image generated");
}

// Stable Speech Generation
export async function generateAISpeech(text: string, voice: string = 'Kore') {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Speak this clearly: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: voice },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("No audio generated");
  return base64Audio;
}

export function encodePCM(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

export function decodePCM(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
