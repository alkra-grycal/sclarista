
import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from "firebase/auth";
import { 
  getFirestore, 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  deleteDoc, 
  doc, 
  updateDoc, 
  serverTimestamp 
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyC4gSL9BLXzTY7ApcrURMD9O3EyqtYuvbQ",
  authDomain: "sclarista-grycal.firebaseapp.com",
  databaseURL: "https://sclarista-grycal-default-rtdb.firebaseio.com",
  projectId: "sclarista-grycal",
  storageBucket: "sclarista-grycal.firebasestorage.app",
  messagingSenderId: "793914375122",
  appId: "1:793914375122:web:c88a0bb04e24c3ec74e60b",
  measurementId: "G-BVT4TDBRTF"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

export { 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword 
};

// Firestore History Logic
export const saveChatHistory = async (userId: string, title: string, messages: any[]) => {
  return await addDoc(collection(db, "chats"), {
    userId,
    title,
    messages,
    lastUpdated: serverTimestamp()
  });
};

export const updateChatHistory = async (chatId: string, messages: any[]) => {
  const chatRef = doc(db, "chats", chatId);
  return await updateDoc(chatRef, {
    messages,
    lastUpdated: serverTimestamp()
  });
};

export const getChatHistories = async (userId: string) => {
  const q = query(collection(db, "chats"), where("userId", "==", userId), orderBy("lastUpdated", "desc"));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const deleteChatHistory = async (chatId: string) => {
  return await deleteDoc(doc(db, "chats", chatId));
};
