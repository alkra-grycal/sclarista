
import React, { useState, useEffect } from 'react';
import { auth, getChatHistories, deleteChatHistory } from '../services/firebaseService';
import { ChatHistory } from '../types';

interface HistoryProps {
    onSelectChat: (chatId: string) => void;
}

const History: React.FC<HistoryProps> = ({ onSelectChat }) => {
    const [histories, setHistories] = useState<ChatHistory[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchHistory = async () => {
            const user = auth.currentUser;
            if (user) {
                const data: any = await getChatHistories(user.uid);
                setHistories(data);
            }
            setLoading(false);
        };
        fetchHistory();
    }, []);

    const handleDelete = async (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        if (confirm("Permanently erase this chat memory?")) {
            await deleteChatHistory(id);
            setHistories(prev => prev.filter(h => h.id !== id));
        }
    };

    if (loading) return <div className="h-full flex items-center justify-center text-zinc-500">Scanning neural logs...</div>;

    return (
        <div className="h-full flex flex-col bg-zinc-950 p-6 md:p-10 overflow-y-auto custom-scrollbar">
            <div className="max-w-4xl mx-auto w-full space-y-10">
                <header className="space-y-2">
                    <h1 className="text-4xl font-black text-white">Chat <span className="gradient-text">Memory</span></h1>
                    <p className="text-zinc-500 uppercase tracking-widest text-xs font-bold">Manage your historical neural connections</p>
                </header>

                {histories.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
                        <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center text-zinc-700">
                            <i className="fas fa-brain text-4xl opacity-20"></i>
                        </div>
                        <p className="text-zinc-400 text-lg">No memory entries found. Start a new conversation to populate this space.</p>
                    </div>
                ) : (
                    <div className="grid gap-4">
                        {histories.map(chat => (
                            <div 
                                key={chat.id} 
                                onClick={() => onSelectChat(chat.id)}
                                className="glass p-6 rounded-[28px] group cursor-pointer hover:bg-white/5 transition-all border-white/5 flex items-center justify-between"
                            >
                                <div className="space-y-1">
                                    <h3 className="text-white font-bold text-lg group-hover:text-blue-400 transition-colors">{chat.title}</h3>
                                    <p className="text-zinc-500 text-xs font-medium uppercase tracking-widest">
                                        {chat.lastUpdated?.toDate ? chat.lastUpdated.toDate().toLocaleString() : 'Just now'}
                                    </p>
                                </div>
                                <div className="flex items-center gap-3">
                                    <button 
                                        onClick={(e) => handleDelete(e, chat.id)}
                                        className="w-10 h-10 rounded-xl bg-red-500/10 text-red-500 opacity-0 group-hover:opacity-100 transition-all hover:bg-red-500/20"
                                    >
                                        <i className="fas fa-trash-can text-sm"></i>
                                    </button>
                                    <i className="fas fa-chevron-right text-zinc-600 group-hover:text-white group-hover:translate-x-1 transition-all"></i>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default History;
