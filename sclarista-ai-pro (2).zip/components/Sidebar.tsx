
import React, { useState } from 'react';
import { AppMode, ThemeMode } from '../types';
import { auth, signOut } from '../services/firebaseService';

interface SidebarProps {
  currentMode: AppMode;
  setMode: (mode: AppMode) => void;
  theme: ThemeMode;
}

const Sidebar: React.FC<SidebarProps> = ({ currentMode, setMode, theme }) => {
  const user = auth.currentUser;
  const [clickCount, setClickCount] = useState(0);
  
  const handleLogoClick = () => {
    setClickCount(prev => prev + 1);
    if (clickCount + 1 >= 3) {
      alert("Made for Trinity by Grycal 🌌");
      setClickCount(0);
    }
    setTimeout(() => setClickCount(0), 1000);
  };
  
  const navItems = [
    { mode: AppMode.CHAT, icon: 'fa-message', label: 'Sclarista Chat' },
    { mode: AppMode.LIVE, icon: 'fa-bolt', label: 'Neural Link' },
    { mode: AppMode.UTILITIES, icon: 'fa-screwdriver-wrench', label: 'AI Utilities' },
  ];

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <div className={`w-20 md:w-64 glass border-r h-screen flex flex-col p-4 transition-all duration-300 z-20 ${theme === 'LIGHT' ? 'border-zinc-200' : 'border-white/5'}`}>
      <div 
        onClick={handleLogoClick}
        className="flex items-center gap-3 mb-10 px-2 cursor-pointer group"
      >
        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20 group-hover:scale-110 transition-transform">
          <i className="fas fa-bolt text-white text-xl"></i>
        </div>
        <span className={`hidden md:block font-bold text-xl tracking-tight group-active:scale-95 transition-all ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>Sclarista AI</span>
      </div>

      <nav className="space-y-2 flex-1">
        {navItems.map((item) => (
          <button
            key={item.mode}
            onClick={() => setMode(item.mode)}
            className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all ${
              currentMode === item.mode
                ? (theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-900 shadow-sm border border-zinc-200' : 'bg-white/10 text-white shadow-sm border border-white/10')
                : (theme === 'LIGHT' ? 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100/50' : 'text-zinc-400 hover:text-white hover:bg-white/5')
            }`}
          >
            <i className={`fas ${item.icon} w-6 text-center text-lg`}></i>
            <span className="hidden md:block font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className={`mt-auto pt-6 border-t space-y-4 ${theme === 'LIGHT' ? 'border-zinc-200' : 'border-white/5'}`}>
        {user && (
          <div className={`hidden md:block p-3 rounded-xl border overflow-hidden ${theme === 'LIGHT' ? 'bg-zinc-100/50 border-zinc-200' : 'bg-white/5 border-white/5'}`}>
            <p className="text-[10px] text-zinc-500 font-semibold mb-1 uppercase tracking-widest">Authorized User</p>
            <p className={`text-xs font-medium truncate ${theme === 'LIGHT' ? 'text-zinc-700' : 'text-zinc-300'}`}>{user.displayName || user.email}</p>
          </div>
        )}
        
        <button 
          onClick={() => setMode(AppMode.SETTINGS)}
          className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all ${
              currentMode === AppMode.SETTINGS
                ? (theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-900 shadow-sm border border-zinc-200' : 'bg-white/10 text-white shadow-sm border border-white/10')
                : (theme === 'LIGHT' ? 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100/50' : 'text-zinc-400 hover:text-white hover:bg-white/5')
            }`}
        >
          <i className="fas fa-gear w-6 text-center"></i>
          <span className="hidden md:block text-sm font-medium">Settings</span>
        </button>

        <button 
          onClick={handleLogout}
          className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all ${theme === 'LIGHT' ? 'text-zinc-500 hover:text-red-500 hover:bg-red-50' : 'text-zinc-400 hover:text-red-400 hover:bg-red-400/5'}`}
        >
          <i className="fas fa-right-from-bracket w-6 text-center"></i>
          <span className="hidden md:block text-sm font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;