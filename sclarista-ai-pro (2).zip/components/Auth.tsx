
import React, { useState } from 'react';
import { 
  auth, 
  googleProvider, 
  signInWithPopup, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword 
} from '../services/firebaseService';

const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const handleGoogleSignIn = async () => {
    try {
      setGoogleLoading(true);
      setError('');
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-screen flex items-center justify-center bg-zinc-950 p-4 md:p-8">
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-600 rounded-full blur-[150px]"></div>
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-blue-600 rounded-full blur-[120px]"></div>
      </div>

      <div className="max-w-4xl w-full grid grid-cols-1 lg:grid-cols-2 glass rounded-[40px] overflow-hidden z-10 border-white/5 shadow-2xl animate-in zoom-in-95 duration-500">
        <div className="hidden lg:flex flex-col justify-center p-12 bg-gradient-to-br from-blue-600/20 to-purple-600/20 border-r border-white/5 relative overflow-hidden">
          <div className="relative z-10 space-y-6">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-2xl">
              <i className="fas fa-bolt text-black text-2xl"></i>
            </div>
            <h2 className="text-5xl font-black text-white leading-tight">Sclarista AI <br/><span className="gradient-text">Neural Core</span></h2>
            <p className="text-zinc-400 text-lg">Experience high-speed multi-modal intelligence. Chat, synthesize, and see through the neural matrix.</p>
            <div className="flex gap-4 pt-4">
              <div className="px-4 py-2 bg-white/5 rounded-full text-xs font-bold text-zinc-300 border border-white/10 uppercase tracking-widest">Neural Link</div>
              <div className="px-4 py-2 bg-white/5 rounded-full text-xs font-bold text-zinc-300 border border-white/10 uppercase tracking-widest">Image Synthesis</div>
            </div>
          </div>
          <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl"></div>
        </div>

        <div className="p-8 md:p-12 flex flex-col justify-center space-y-8">
          <div className="text-center lg:text-left space-y-2">
            <h1 className="text-3xl font-black text-white tracking-tight">
              {isLogin ? 'Welcome Operator' : 'Register Identity'}
            </h1>
            <p className="text-zinc-400 text-sm">
              Connect to the Sclarista Neural Network.
            </p>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-xs p-4 rounded-2xl text-center animate-in fade-in slide-in-from-top-2">
              {error}
            </div>
          )}

          <div className="space-y-4">
            <button
              onClick={handleGoogleSignIn}
              disabled={loading || googleLoading}
              className="w-full py-4 glass hover:bg-white/10 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-3 border-white/10 disabled:opacity-50"
            >
              {googleLoading ? (
                <i className="fas fa-circle-notch fa-spin text-xl text-blue-400"></i>
              ) : (
                <i className="fab fa-google text-xl text-blue-400"></i>
              )}
              {googleLoading ? 'Synchronizing...' : 'Continue with Google'}
            </button>

            <div className="relative py-2">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-white/5"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase tracking-widest">
                <span className="bg-[#121214] px-4 text-zinc-500">Or credentials</span>
              </div>
            </div>

            <form onSubmit={handleEmailAuth} className="space-y-4">
              <div className="space-y-3">
                <div className="relative">
                  <i className="fas fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-zinc-500 text-sm"></i>
                  <input
                    type="email"
                    placeholder="Nexus ID (Email)"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-6 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all placeholder:text-zinc-600"
                  />
                </div>
                <div className="relative">
                  <i className="fas fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-zinc-500 text-sm"></i>
                  <input
                    type="password"
                    placeholder="Security Passcode"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-6 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all placeholder:text-zinc-600"
                  />
                </div>
              </div>
              <button
                type="submit"
                disabled={loading || googleLoading}
                className="w-full py-4 bg-white text-black font-bold rounded-2xl hover:bg-zinc-200 transition-all shadow-xl disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? <i className="fas fa-circle-notch fa-spin mr-1"></i> : null}
                {loading ? 'Processing...' : (isLogin ? 'Establish Link' : 'Initialize Matrix')}
              </button>
            </form>
          </div>

          <div className="text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-sm text-zinc-500 hover:text-white transition-colors"
            >
              {isLogin ? "New user? Create Matrix entry" : "Existing user? Connect to Matrix"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;