
import React, { useState, useRef, useEffect } from 'react';
import { sendMessageStream } from '../services/geminiService';
import { ChatMessage, ThemeMode } from '../types';
import { auth, saveChatHistory, db } from '../services/firebaseService';
import { doc, getDoc } from 'firebase/firestore';

interface ChatInterfaceProps {
  initialChatId?: string;
  theme: ThemeMode;
}

const SUGGESTIONS = [
  { text: "Plan a futuristic vacation 🚀", icon: "fa-rocket" },
  { text: "Write code for a neon clock 💻", icon: "fa-code" },
  { text: "Brainstorm a sci-fi novel 📚", icon: "fa-book-open" },
  { text: "Explain quantum physics simply ⚛️", icon: "fa-atom" }
];

const ChatInterface: React.FC<ChatInterfaceProps> = ({ initialChatId, theme }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [currentChatId, setCurrentChatId] = useState<string | null>(initialChatId || null);
  const [customInstructions, setCustomInstructions] = useState("");
  const [usePro, setUsePro] = useState(false);
  const [persona, setPersona] = useState("Warm Companion");
  const [selectedFile, setSelectedFile] = useState<{ data: string; mimeType: string; name: string } | null>(null);
  const [isListening, setIsListening] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(prev => prev + (prev ? " " : "") + transcript);
        setIsListening(false);
      };
      recognitionRef.current.onerror = () => setIsListening(false);
      recognitionRef.current.onend = () => setIsListening(false);
    }

    const fetchSettings = async () => {
      const user = auth.currentUser;
      if (user) {
        const settingsDoc = await getDoc(doc(db, "settings", user.uid));
        if (settingsDoc.exists()) {
          const data = settingsDoc.data();
          setCustomInstructions(data.customInstructions || "");
          setUsePro(data.usePro || false);
          setPersona(data.persona || "Warm Companion");
          if (data.accentColor) {
              document.documentElement.style.setProperty('--accent-color', data.accentColor);
          }
        }
      }
    };
    fetchSettings();
  }, []);

  useEffect(() => {
    if (initialChatId) {
        const fetchChat = async () => {
            const chatDoc = await getDoc(doc(db, "chats", initialChatId));
            if (chatDoc.exists()) {
                setMessages(chatDoc.data().messages || []);
                setCurrentChatId(initialChatId);
            }
        };
        fetchChat();
    } else {
        setMessages([]);
        setCurrentChatId(null);
    }
  }, [initialChatId]);

  useEffect(() => {
    if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (e) {
        console.error("Speech recognition failed to start", e);
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(',')[1];
        setSelectedFile({ data: base64, mimeType: file.type, name: file.name });
      };
      reader.readAsDataURL(file);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-24 left-1/2 -translate-x-1/2 bg-white text-black px-6 py-3 rounded-2xl font-bold shadow-2xl z-50 animate-bounce';
    toast.innerText = 'Copied to Matrix Clipboard! ⚡';
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2000);
  };

  const cleanText = (text: string) => {
    return text.replace(/[#*`_~]/g, '');
  };

  const handleApiError = async (error: any) => {
    const errorMessage = typeof error === 'string' ? error.toLowerCase() : (error?.message?.toLowerCase() || "");
    if (errorMessage.includes('permission denied') || errorMessage.includes('403') || errorMessage.includes('requested entity was not found')) {
      alert("Sclarista needs a fresh API link. Opening selection...");
      await (window as any).aistudio.openSelectKey();
    } else {
      alert("Neural Bridge Error: " + (error?.message || error || "Synthesis failed."));
    }
  };

  const handleSubmit = async (e?: React.FormEvent, suggestionText?: string) => {
    e?.preventDefault();
    const currentInput = suggestionText || input;
    if ((!currentInput.trim() && !selectedFile) || isTyping) return;

    const currentFile = selectedFile;
    
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: currentFile ? `[File: ${currentFile.name}] ${currentInput}` : currentInput,
      timestamp: new Date()
    };

    const aiMessageId = (Date.now() + 1).toString();
    const aiMessage: ChatMessage = {
      id: aiMessageId,
      role: 'model',
      content: '',
      timestamp: new Date(),
      isLoading: true
    };

    setMessages(prev => [...prev, userMessage, aiMessage]);
    setInput('');
    setSelectedFile(null);
    setIsTyping(true);

    try {
      let accumulatedText = "";
      const stream = sendMessageStream(currentInput, messages, customInstructions, currentFile || undefined, usePro, persona);
      
      for await (const chunk of stream) {
        accumulatedText += chunk.text;
        const cleaned = cleanText(accumulatedText);
        setMessages(prev => 
          prev.map(msg => 
            msg.id === aiMessageId 
              ? { ...msg, content: cleaned, isLoading: false }
              : msg
          )
        );
      }

      const user = auth.currentUser;
      if (user) {
        const finalMsgs = [...messages, userMessage, { ...aiMessage, content: accumulatedText, isLoading: false }];
        if (!currentChatId) {
          const res = await saveChatHistory(user.uid, currentInput.slice(0, 30) || "Analysis Session", finalMsgs);
          setCurrentChatId(res.id);
        }
      }
    } catch (error: any) {
      await handleApiError(error);
      setMessages(prev => prev.filter(m => m.id !== aiMessageId));
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className={`flex flex-col h-full overflow-hidden transition-colors duration-500 ${theme === 'LIGHT' ? 'bg-zinc-50' : 'bg-zinc-950'}`}>
      <div ref={scrollRef} className="flex-1 overflow-y-auto custom-scrollbar p-4 md:p-8 space-y-8">
        {messages.length === 0 && (
          <div className="min-h-full flex flex-col items-center justify-center text-center max-w-2xl mx-auto space-y-12 py-12">
            <div className="w-24 h-24 rounded-[32px] bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center animate-pulse shadow-2xl shadow-blue-500/20">
              <i className="fas fa-sparkles text-white text-4xl"></i>
            </div>
            <div className="space-y-4">
              <h2 className={`text-4xl md:text-5xl font-black tracking-tight leading-tight ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>Sclarista <span className="gradient-text">AI</span></h2>
              <p className="text-zinc-500 text-lg md:text-xl font-medium">
                {persona} Mode Active. How can I assist you today? ✨
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-xl">
                {SUGGESTIONS.map((suggestion, i) => (
                    <button
                        key={i}
                        onClick={() => handleSubmit(undefined, suggestion.text)}
                        className={`glass p-4 rounded-2xl transition-all text-left flex items-center gap-4 group ${theme === 'LIGHT' ? 'hover:bg-zinc-100 border-zinc-200' : 'border-white/5 hover:bg-white/10'}`}
                    >
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-400 group-hover:bg-purple-600 group-hover:text-white' : 'bg-white/5 text-zinc-400 group-hover:text-white group-hover:bg-purple-500/20'}`}>
                            <i className={`fas ${suggestion.icon}`}></i>
                        </div>
                        <span className={`text-sm font-bold ${theme === 'LIGHT' ? 'text-zinc-600 group-hover:text-zinc-900' : 'text-zinc-300 group-hover:text-white'}`}>{suggestion.text}</span>
                    </button>
                ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`group relative max-w-[90%] md:max-w-[80%] rounded-3xl p-5 md:p-7 shadow-2xl border transition-all ${
              msg.role === 'user' 
                ? (theme === 'LIGHT' ? 'bg-zinc-900 text-white border-zinc-900' : 'bg-zinc-100 text-black border-white')
                : (theme === 'LIGHT' ? 'bg-white text-zinc-900 border-zinc-200' : 'glass border-white/5 text-zinc-100')
            }`}>
              {msg.role === 'model' && (
                <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2 text-[10px] font-black text-purple-400 uppercase tracking-[0.2em]">
                        <i className="fas fa-star text-[8px]"></i> Sclarista {persona}
                    </div>
                    <button 
                        onClick={() => copyToClipboard(msg.content as string)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-2 hover:bg-zinc-100 rounded-lg text-zinc-500"
                    >
                        <i className="fas fa-copy text-xs"></i>
                    </button>
                </div>
              )}
              <div className="whitespace-pre-wrap leading-relaxed text-base md:text-lg font-medium">
                {msg.content as string}
                {msg.isLoading && (
                  <span className="inline-block w-2 h-5 bg-purple-400 animate-pulse ml-1 rounded-sm align-middle"></span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className={`p-4 md:p-8 border-t transition-colors duration-500 ${theme === 'LIGHT' ? 'bg-zinc-50 border-zinc-200' : 'bg-zinc-950 border-white/5'}`}>
        {selectedFile && (
            <div className={`max-w-5xl mx-auto mb-4 flex items-center gap-4 border p-3 rounded-2xl animate-in fade-in slide-in-from-bottom-2 ${theme === 'LIGHT' ? 'bg-white border-zinc-200' : 'bg-white/5 border-white/10'}`}>
                <div className="w-10 h-10 bg-purple-500/20 rounded-xl flex items-center justify-center text-purple-400">
                    <i className="fas fa-file"></i>
                </div>
                <div className={`flex-1 text-sm font-bold truncate ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-zinc-300'}`}>
                    {selectedFile.name}
                </div>
                <button onClick={() => setSelectedFile(null)} className="text-zinc-500 hover:text-red-400 p-2">
                    <i className="fas fa-times"></i>
                </button>
            </div>
        )}

        <form onSubmit={handleSubmit} className="max-w-5xl mx-auto flex items-center gap-3">
          <button 
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className={`w-14 h-14 shrink-0 glass rounded-2xl flex items-center justify-center transition-all shadow-xl ${theme === 'LIGHT' ? 'bg-white border-zinc-200 text-zinc-400 hover:text-zinc-900' : 'border-white/10 text-zinc-400 hover:text-white'}`}
          >
            <i className="fas fa-paperclip"></i>
          </button>
          <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileSelect} />

          <div className="relative flex-1">
            <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={`Talk to Sclarista (${persona})...`}
                className={`w-full border rounded-2xl py-5 pl-8 pr-16 focus:outline-none focus:ring-4 focus:ring-purple-500/10 focus:border-purple-500/30 transition-all text-lg shadow-2xl ${theme === 'LIGHT' ? 'bg-white border-zinc-200 text-zinc-900' : 'bg-white/5 border-white/10 text-zinc-100'}`}
            />
            <button 
                type="button"
                onClick={toggleListening}
                className={`absolute right-4 top-4 bottom-4 w-10 flex items-center justify-center rounded-xl transition-all ${isListening ? 'bg-red-500 text-white animate-pulse' : 'text-zinc-500 hover:text-zinc-900'}`}
            >
                <i className={`fas ${isListening ? 'fa-stop' : 'fa-microphone'}`}></i>
            </button>
          </div>

          <button 
            type="submit"
            disabled={isTyping || (!input.trim() && !selectedFile)}
            className="w-14 h-14 shrink-0 rounded-2xl bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:opacity-90 transition-all disabled:opacity-50 shadow-xl flex items-center justify-center"
          >
            <i className={`fas ${isTyping ? 'fa-circle-notch fa-spin' : 'fa-arrow-up'}`}></i>
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;
