
import React, { useState, useRef } from 'react';
import { generateAIImage, generateAISpeech, decodeAudioData, decodePCM } from '../services/geminiService';
import { GeneratedMedia, ThemeMode } from '../types';

interface UtilitiesProps {
  theme: ThemeMode;
}

const Utilities: React.FC<UtilitiesProps> = ({ theme }) => {
    const [activeTool, setActiveTool] = useState<'image' | 'speech'>('image');
    const [prompt, setPrompt] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [results, setResults] = useState<GeneratedMedia[]>([]);
    const audioContextRef = useRef<AudioContext | null>(null);

    const playSpeech = async (base64: string) => {
        try {
            if (!audioContextRef.current) {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            }
            const ctx = audioContextRef.current;
            if (ctx.state === 'suspended') await ctx.resume();
            
            const pcmData = decodePCM(base64);
            const buffer = await decodeAudioData(pcmData, ctx, 24000, 1);
            const source = ctx.createBufferSource();
            source.buffer = buffer;
            source.connect(ctx.destination);
            source.start();
        } catch (e) {
            console.error("Audio playback error:", e);
        }
    };

    const handleGenerate = async () => {
        if (!prompt.trim()) return;
        setIsGenerating(true);
        const currentPrompt = prompt;
        
        try {
            if (activeTool === 'image') {
                const url = await generateAIImage(currentPrompt);
                setResults(prev => [{ id: Date.now().toString(), type: 'image', url, prompt: currentPrompt, timestamp: new Date() }, ...prev]);
            } else if (activeTool === 'speech') {
                const base64 = await generateAISpeech(currentPrompt);
                await playSpeech(base64);
                setResults(prev => [{ id: Date.now().toString(), type: 'audio', url: base64, prompt: currentPrompt, timestamp: new Date() }, ...prev]);
            }
            setPrompt('');
        } catch (err) {
            console.error("Generation error:", err);
            alert("Sclarista encountered a synthesis glitch. ✨");
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className={`h-full flex flex-col p-6 md:p-10 overflow-y-auto custom-scrollbar transition-colors duration-500 ${theme === 'LIGHT' ? 'bg-zinc-50' : 'bg-zinc-950'}`}>
            <div className="max-w-6xl mx-auto w-full space-y-12">
                <header className="space-y-4">
                    <h1 className={`text-4xl md:text-5xl font-black tracking-tight ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>AI <span className="gradient-text">Utilities</span></h1>
                    <p className="text-zinc-500 font-bold uppercase tracking-[0.2em] text-xs">Standard Neural Synthesis</p>
                </header>

                <div className={`flex flex-wrap gap-2 p-1 rounded-3xl border w-fit ${theme === 'LIGHT' ? 'bg-white border-zinc-200 shadow-sm' : 'bg-white/5 border-white/5'}`}>
                    {(['image', 'speech'] as const).map(tool => (
                        <button
                            key={tool}
                            onClick={() => { setActiveTool(tool); setPrompt(''); }}
                            className={`px-8 py-3 rounded-2xl font-black transition-all text-xs uppercase tracking-widest ${activeTool === tool ? (theme === 'LIGHT' ? 'bg-zinc-900 text-white shadow-xl' : 'bg-white text-black shadow-xl') : 'text-zinc-500 hover:text-zinc-900'}`}
                        >
                            <i className={`fas fa-${tool === 'image' ? 'image' : 'waveform'} mr-2`}></i>
                            {tool} Gen
                        </button>
                    ))}
                </div>

                <section className={`glass rounded-[40px] p-8 md:p-10 space-y-8 relative overflow-hidden shadow-2xl transition-colors ${theme === 'LIGHT' ? 'bg-white border-zinc-200' : 'border-white/5'}`}>
                    <div className="space-y-6">
                        <label className="text-xs font-black text-zinc-400 uppercase tracking-widest block">Input Directives</label>
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder={activeTool === 'image' ? "Describe your masterpiece..." : "Enter text for Sclarista to speak..."}
                            className={`w-full border rounded-3xl p-6 focus:outline-none focus:ring-2 focus:ring-purple-500/50 min-h-[150px] text-lg transition-all ${theme === 'LIGHT' ? 'bg-zinc-100 border-zinc-200 text-zinc-900 placeholder:text-zinc-400' : 'bg-white/5 border-white/10 text-white placeholder:text-zinc-700'}`}
                        />
                    </div>

                    <button
                        onClick={handleGenerate}
                        disabled={isGenerating || !prompt.trim()}
                        className={`w-full py-6 font-black text-xl rounded-3xl transition-all shadow-2xl disabled:opacity-50 ${theme === 'LIGHT' ? 'bg-zinc-900 text-white hover:bg-zinc-800' : 'bg-white text-black hover:bg-zinc-200'}`}
                    >
                        {isGenerating ? (
                            <span className="flex items-center justify-center gap-3">
                                <i className="fas fa-circle-notch fa-spin"></i> Synthesizing...
                            </span>
                        ) : `Generate ${activeTool}`}
                    </button>
                </section>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {results.map(item => (
                        <div key={item.id} className={`glass rounded-[32px] overflow-hidden group shadow-2xl animate-in zoom-in-95 duration-300 ${theme === 'LIGHT' ? 'bg-white border-zinc-200' : 'border-white/5'}`}>
                            {item.type === 'image' && <img src={item.url} className="w-full aspect-square object-cover" />}
                            {item.type === 'audio' && (
                                <div className="p-8 flex flex-col items-center gap-6">
                                    <div className="w-20 h-20 bg-purple-500/10 rounded-full flex items-center justify-center text-purple-400 shadow-xl">
                                        <i className="fas fa-waveform text-3xl animate-pulse"></i>
                                    </div>
                                    <button 
                                        onClick={() => playSpeech(item.url)} 
                                        className={`w-full py-4 rounded-2xl font-black text-[10px] transition-all uppercase tracking-widest ${theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-900 hover:bg-zinc-200' : 'bg-white/10 text-white hover:bg-white/20'}`}
                                    >
                                        <i className="fas fa-play mr-2"></i> Replay Synthesis
                                    </button>
                                </div>
                            )}
                            <div className={`p-6 border-t backdrop-blur-md ${theme === 'LIGHT' ? 'bg-zinc-50 border-zinc-200' : 'bg-black/40 border-white/5'}`}>
                                <p className={`text-sm font-bold italic ${theme === 'LIGHT' ? 'text-zinc-600' : 'text-zinc-400'}`}>"{item.prompt}"</p>
                                <div className="mt-4 flex gap-2">
                                    <a href={item.url} download={`sclarista-${item.id}`} className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest text-center transition-all ${theme === 'LIGHT' ? 'bg-zinc-900 text-white' : 'bg-white/5 text-zinc-300 hover:bg-white/10'}`}>Download Archive</a>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Utilities;
