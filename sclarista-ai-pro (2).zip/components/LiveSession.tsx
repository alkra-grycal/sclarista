
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { getAIClient, encodePCM, decodePCM, decodeAudioData, analyzeScene } from '../services/geminiService';
import { Modality } from '@google/genai';
import { ThemeMode, SceneAnalysisResult } from '../types';

interface LiveSessionProps {
  theme: ThemeMode;
}

const VOICES = [
  { id: 'Zephyr', label: 'Female', icon: 'fa-venus' },
  { id: 'Fenrir', label: 'Male', icon: 'fa-mars' },
  { id: 'Puck', label: 'Playful', icon: 'fa-ghost' },
  { id: 'Kore', label: 'Serene', icon: 'fa-leaf' }
];

const LiveSession: React.FC<LiveSessionProps> = ({ theme }) => {
  const [isActive, setIsActive] = useState(false);
  const [status, setStatus] = useState("Disconnected");
  const [isMuted, setIsMuted] = useState(false);
  const [isVisionEnabled, setIsVisionEnabled] = useState(false);
  const [voice, setVoice] = useState<string>('Zephyr');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<SceneAnalysisResult | null>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const visionIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (videoRef.current && streamRef.current && isVisionEnabled) {
        videoRef.current.srcObject = streamRef.current;
    }
  }, [isActive, isVisionEnabled]);

  const stopSession = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.close?.();
      sessionRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (visionIntervalRef.current) {
      window.clearInterval(visionIntervalRef.current);
      visionIntervalRef.current = null;
    }
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    setIsActive(false);
    setStatus("Disconnected");
  }, []);

  const handleSceneAnalysis = async () => {
    if (!videoRef.current || isAnalyzing) return;
    
    setIsAnalyzing(true);
    setAnalysisResult(null);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        const base64 = canvas.toDataURL('image/jpeg', 0.9).split(',')[1];
        const result = await analyzeScene(base64);
        setAnalysisResult(result);
      }
    } catch (err) {
      console.error(err);
      alert("Neural Analysis disrupted. Check camera link.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const startSession = async () => {
    try {
      setStatus("Initializing Neural Link...");
      const ai = getAIClient();
      
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: isVisionEnabled ? { width: 1280, height: 720 } : false 
      });
      
      streamRef.current = stream;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus("Neural Bridge Connected");
            setIsActive(true);
            
            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              if (isMuted) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = {
                data: encodePCM(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current!.destination);

            if (isVisionEnabled && canvasRef.current) {
                const canvas = canvasRef.current;
                const ctx = canvas.getContext('2d');
                visionIntervalRef.current = window.setInterval(() => {
                    const video = videoRef.current;
                    if (video && video.videoWidth > 0 && ctx) {
                        canvas.width = 480;
                        canvas.height = 270;
                        ctx.save();
                        ctx.scale(-1, 1);
                        ctx.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
                        ctx.restore();
                        const base64Data = canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
                        sessionPromise.then(session => session.sendRealtimeInput({
                            media: { data: base64Data, mimeType: 'image/jpeg' }
                        }));
                    }
                }, 1000);
            }
          },
          onmessage: async (message) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && outputAudioContextRef.current) {
              const ctx = outputAudioContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decodePCM(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => sourcesRef.current.delete(source));
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error(e);
            setStatus("Neural disruption detected.");
            stopSession();
          },
          onclose: () => stopSession()
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: voice as any } }
          },
          systemInstruction: 'You are Sclarista AI in Neural Link mode. Keep responses conversational and brief. You can see through the user camera if enabled.'
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setStatus("Neural Link Failed. Check hardware.");
    }
  };

  return (
    <div className={`h-full flex flex-col items-center justify-center p-6 overflow-hidden relative ${theme === 'LIGHT' ? 'bg-zinc-50' : 'bg-zinc-950'}`}>
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none overflow-hidden">
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full blur-[150px] animate-pulse ${theme === 'LIGHT' ? 'bg-blue-200' : 'bg-purple-600'}`}></div>
      </div>

      <div className="max-w-xl w-full text-center space-y-6 z-10 flex flex-col h-full justify-center">
        <div className="relative">
          {isVisionEnabled && isActive ? (
              <div className={`w-full aspect-video rounded-[40px] border-4 bg-black overflow-hidden relative shadow-2xl ${theme === 'LIGHT' ? 'border-zinc-200' : 'border-white/5'}`}>
                  <video 
                    ref={videoRef} 
                    autoPlay 
                    playsInline 
                    muted 
                    className="w-full h-full object-cover opacity-90"
                    style={{ transform: 'scaleX(-1)' }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="w-24 h-24 rounded-full border border-purple-500/30 flex items-center justify-center animate-ping">
                          <i className="fas fa-bolt text-white text-2xl opacity-30"></i>
                      </div>
                  </div>
                  <canvas ref={canvasRef} className="hidden" />
              </div>
          ) : (
            <div className={`w-40 h-40 mx-auto rounded-full border-8 flex items-center justify-center transition-all duration-700 ${theme === 'LIGHT' ? 'border-zinc-200' : 'border-white/5'} ${isActive ? 'scale-110 border-purple-500/20' : 'scale-100'}`}>
                <div className={`w-28 h-28 rounded-full border flex items-center justify-center shadow-2xl transition-colors ${theme === 'LIGHT' ? 'bg-white border-zinc-200' : 'bg-zinc-900 border-white/10'} ${isActive ? 'animate-pulse' : ''}`}>
                    <i className={`fas fa-bolt text-4xl ${theme === 'LIGHT' ? 'text-zinc-400' : 'text-white'}`}></i>
                </div>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h2 className={`text-3xl font-black tracking-tight ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>Neural <span className="gradient-text">Link</span></h2>
          <div className="flex items-center justify-center gap-2">
            <span className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></span>
            <p className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-500">{status}</p>
          </div>
        </div>

        {!isActive && (
          <div className="flex flex-wrap justify-center gap-2 mb-4">
            {VOICES.map(v => (
              <button
                key={v.id}
                onClick={() => setVoice(v.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 ${
                  voice === v.id 
                    ? (theme === 'LIGHT' ? 'bg-zinc-900 text-white border-zinc-900 shadow-lg' : 'bg-white text-black border-white shadow-lg')
                    : (theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-500 border-zinc-200' : 'bg-white/5 text-zinc-500 border-white/10 hover:border-white/20')
                }`}
              >
                <i className={`fas ${v.icon}`}></i>
                {v.label}
              </button>
            ))}
          </div>
        )}

        {isActive && isVisionEnabled && (
          <button
            onClick={handleSceneAnalysis}
            disabled={isAnalyzing}
            className={`w-full py-3 rounded-2xl font-black text-sm uppercase tracking-widest transition-all border ${
              theme === 'LIGHT' 
                ? 'bg-purple-600 text-white border-purple-500 hover:bg-purple-700 shadow-lg' 
                : 'bg-white text-black border-white hover:bg-zinc-200 shadow-lg'
            }`}
          >
            {isAnalyzing ? <><i className="fas fa-circle-notch fa-spin mr-2"></i> Analyzing Reality...</> : <><i className="fas fa-magnifying-glass mr-2"></i> Sync Reality Count</>}
          </button>
        )}

        {analysisResult && (
          <div className={`glass rounded-[32px] p-6 text-left animate-in slide-in-from-bottom-4 duration-500 max-h-[250px] overflow-y-auto custom-scrollbar ${theme === 'LIGHT' ? 'border-zinc-200 bg-white' : ''}`}>
             <h4 className="text-xs font-black uppercase tracking-widest text-purple-500 mb-4">Neural Count Archive</h4>
             <div className="space-y-3">
                {analysisResult.items.map((item, i) => (
                  <div key={i} className="flex items-center justify-between border-b border-zinc-500/10 pb-2">
                    <span className="font-bold text-sm">{item.name}</span>
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black ${theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-900' : 'bg-white/10 text-white'}`}>X {item.count}</span>
                  </div>
                ))}
             </div>
             <p className="mt-4 text-xs text-zinc-500 leading-relaxed italic">"{analysisResult.description}"</p>
          </div>
        )}

        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-center gap-6">
            <button 
              onClick={() => setIsMuted(!isMuted)}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all border ${
                isMuted 
                  ? 'bg-red-500/20 text-red-500 border-red-500/30 shadow-red-500/10' 
                  : (theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-400 border-zinc-200' : 'bg-white/5 text-zinc-400 border-white/10')
              }`}
            >
              <i className={`fas ${isMuted ? 'fa-microphone-slash' : 'fa-microphone'} text-lg`}></i>
            </button>
            
            <button 
              onClick={isActive ? stopSession : startSession}
              className={`flex-1 h-14 rounded-2xl font-black text-base transition-all shadow-xl ${
                isActive 
                  ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-600/20' 
                  : (theme === 'LIGHT' ? 'bg-zinc-900 hover:bg-zinc-800 text-white' : 'bg-white hover:bg-zinc-200 text-black')
              }`}
            >
              {isActive ? 'Break Connection' : 'Establish Neural Link'}
            </button>

            <button 
                onClick={() => setIsVisionEnabled(!isVisionEnabled)}
                disabled={isActive}
                className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all border ${
                  isVisionEnabled 
                    ? 'bg-purple-500/20 text-purple-400 border-purple-500/30 shadow-purple-500/10' 
                    : (theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-400 border-zinc-200' : 'bg-white/5 text-zinc-400 border-white/10')
                }`}
            >
              <i className="fas fa-video text-lg"></i>
            </button>
          </div>
        </div>

        <div className={`glass p-4 rounded-[28px] text-[10px] leading-relaxed uppercase tracking-widest font-bold ${theme === 'LIGHT' ? 'text-zinc-500 border-zinc-200' : 'text-zinc-600 border-white/5'}`}>
          Neural Link syncs multi-modal inputs for real-time intelligence.
        </div>
      </div>
    </div>
  );
};

export default LiveSession;
