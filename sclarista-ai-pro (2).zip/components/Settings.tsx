
import React, { useState, useEffect } from 'react';
import { auth, db } from '../services/firebaseService';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { ThemeMode } from '../types';

interface SettingsProps {
  theme: ThemeMode;
}

const Settings: React.FC<SettingsProps> = ({ theme: currentTheme }) => {
    const [name, setName] = useState("");
    const [birthday, setBirthday] = useState("");
    const [customInstructions, setCustomInstructions] = useState("");
    const [usePro, setUsePro] = useState(false);
    const [persona, setPersona] = useState("Warm Companion");
    const [accentColor, setAccentColor] = useState("#c084fc");
    const [theme, setTheme] = useState<ThemeMode>(currentTheme);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        const fetchSettings = async () => {
            const user = auth.currentUser;
            if (user) {
                const settingsDoc = await getDoc(doc(db, "settings", user.uid));
                if (settingsDoc.exists()) {
                    const data = settingsDoc.data();
                    setName(data.name || "");
                    setBirthday(data.birthday || "");
                    setCustomInstructions(data.customInstructions || "");
                    setUsePro(data.usePro || false);
                    setPersona(data.persona || "Warm Companion");
                    setAccentColor(data.accentColor || "#c084fc");
                    setTheme(data.theme || 'DARK');
                } else {
                    setName(user.displayName || "");
                }
            }
        };
        fetchSettings();
    }, []);

    const handleSave = async () => {
        setIsSaving(true);
        const user = auth.currentUser;
        if (user) {
            await setDoc(doc(db, "settings", user.uid), {
                name,
                birthday,
                customInstructions,
                usePro,
                persona,
                accentColor,
                theme,
                updatedAt: new Date()
            });
            document.documentElement.style.setProperty('--accent-color', accentColor);
            alert("Sclarista Profile Synchronized! ✨");
        }
        setIsSaving(false);
    };

    const personas = ["Warm Companion", "Professional Assistant", "Creative Spark"];
    const themes = [
        { name: "Nebula Purple", color: "#c084fc" },
        { name: "Ocean Blue", color: "#60a5fa" },
        { name: "Emerald Glaze", color: "#34d399" }
    ];

    return (
        <div className={`h-full flex flex-col p-6 md:p-10 overflow-y-auto custom-scrollbar ${theme === 'LIGHT' ? 'bg-zinc-50' : 'bg-zinc-950'}`}>
            <div className="max-w-4xl mx-auto w-full space-y-12 pb-20">
                <header className="space-y-2">
                    <h1 className={`text-4xl font-black ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>Neural <span className="gradient-text">Personalization</span></h1>
                    <p className="text-zinc-500 uppercase tracking-widest text-xs font-bold">Customize your matrix environment</p>
                </header>

                <div className={`glass rounded-[40px] p-8 md:p-12 space-y-10 shadow-2xl ${theme === 'LIGHT' ? 'border-zinc-200' : 'border-white/5'}`}>
                    
                    <section className="space-y-6">
                        <h3 className={`text-xl font-bold flex items-center gap-3 ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>
                            <i className="fas fa-circle-half-stroke text-blue-500"></i> Interface Theme
                        </h3>
                        <div className="flex gap-4">
                            {(['DARK', 'LIGHT'] as ThemeMode[]).map(m => (
                                <button
                                    key={m}
                                    onClick={() => setTheme(m)}
                                    className={`flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all border ${
                                        theme === m 
                                          ? (theme === 'LIGHT' ? 'bg-zinc-900 text-white border-zinc-900' : 'bg-white text-black border-white')
                                          : (theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-500 border-zinc-200' : 'bg-white/5 text-zinc-500 border-white/10')
                                    }`}
                                >
                                    {m === 'DARK' ? <i className="fas fa-moon mr-2"></i> : <i className="fas fa-sun mr-2"></i>}
                                    {m} Mode
                                </button>
                            ))}
                        </div>
                    </section>

                    <section className="space-y-6">
                        <h3 className={`text-xl font-bold flex items-center gap-3 ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>
                            <i className="fas fa-id-badge text-blue-500"></i> Identity Matrix
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <label className="text-xs font-black text-zinc-500 uppercase tracking-widest ml-1">Preferred Name</label>
                                <input
                                    type="text"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    className={`w-full border rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 theme-border transition-colors ${theme === 'LIGHT' ? 'bg-zinc-100/50 border-zinc-200 text-zinc-900' : 'bg-white/5 border-white/10 text-white'}`}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-xs font-black text-zinc-500 uppercase tracking-widest ml-1">Creation Date</label>
                                <input
                                    type="date"
                                    value={birthday}
                                    onChange={(e) => setBirthday(e.target.value)}
                                    className={`w-full border rounded-2xl py-4 px-6 focus:outline-none focus:ring-2 theme-border transition-colors ${theme === 'LIGHT' ? 'bg-zinc-100/50 border-zinc-200 text-zinc-900' : 'bg-white/5 border-white/10 text-white'}`}
                                />
                            </div>
                        </div>
                    </section>

                    <section className="space-y-6">
                        <h3 className={`text-xl font-bold flex items-center gap-3 ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>
                            <i className="fas fa-ghost text-purple-500"></i> AI Persona Presets
                        </h3>
                        <div className="flex flex-wrap gap-3">
                            {personas.map(p => (
                                <button
                                    key={p}
                                    onClick={() => setPersona(p)}
                                    className={`px-6 py-3 rounded-2xl font-bold text-sm transition-all border ${
                                        persona === p 
                                          ? (theme === 'LIGHT' ? 'bg-zinc-900 text-white border-zinc-900' : 'bg-white text-black border-white')
                                          : (theme === 'LIGHT' ? 'bg-zinc-100 text-zinc-500 border-zinc-200' : 'bg-white/5 text-zinc-500 border-white/10')
                                    }`}
                                >
                                    {p}
                                </button>
                            ))}
                        </div>
                    </section>

                    <section className="space-y-6">
                        <h3 className={`text-xl font-bold flex items-center gap-3 ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>
                            <i className="fas fa-bolt text-yellow-500"></i> Intelligence Level
                        </h3>
                        <div className={`flex items-center justify-between p-6 rounded-3xl border ${theme === 'LIGHT' ? 'bg-zinc-100/50 border-zinc-200' : 'bg-white/5 border-white/10'}`}>
                            <div>
                                <h4 className={`font-bold ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>Pro Neural Link</h4>
                                <p className="text-sm text-zinc-500">Enable Gemini 3 Pro reasoning engine</p>
                            </div>
                            <button 
                                onClick={() => setUsePro(!usePro)}
                                className={`w-14 h-8 rounded-full p-1 transition-all ${usePro ? (theme === 'LIGHT' ? 'bg-zinc-900' : 'bg-white') : 'bg-zinc-700'}`}
                            >
                                <div className={`w-6 h-6 rounded-full transition-all ${usePro ? 'translate-x-6 bg-black' : 'translate-x-0 bg-white'}`}></div>
                            </button>
                        </div>
                    </section>

                    <section className="space-y-6">
                        <h3 className={`text-xl font-bold flex items-center gap-3 ${theme === 'LIGHT' ? 'text-zinc-900' : 'text-white'}`}>
                            <i className="fas fa-scroll text-zinc-400"></i> Deep Directive
                        </h3>
                        <textarea
                            value={customInstructions}
                            onChange={(e) => setCustomInstructions(e.target.value)}
                            className={`w-full border rounded-3xl py-4 px-6 focus:outline-none focus:ring-2 theme-border min-h-[120px] transition-colors ${theme === 'LIGHT' ? 'bg-zinc-100/50 border-zinc-200 text-zinc-900' : 'bg-white/5 border-white/10 text-white'}`}
                            placeholder="Overwrite default AI behavioral matrix..."
                        />
                    </section>

                    <button
                        onClick={handleSave}
                        disabled={isSaving}
                        className={`w-full py-5 font-black text-lg rounded-3xl transition-all shadow-xl disabled:opacity-50 ${theme === 'LIGHT' ? 'bg-zinc-900 text-white hover:bg-zinc-800' : 'bg-white text-black hover:bg-zinc-200'}`}
                    >
                        {isSaving ? <i className="fas fa-circle-notch fa-spin mr-2"></i> : null}
                        Apply Synthesis
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Settings;
