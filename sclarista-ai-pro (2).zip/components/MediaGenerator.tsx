
import React, { useState } from 'react';
import { generateAIImage } from '../services/geminiService';
import { GeneratedMedia } from '../types';

const MediaGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [history, setHistory] = useState<GeneratedMedia[]>([]);
  const [selectedQuality, setSelectedQuality] = useState<'1K' | '2K'>('1K');

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    try {
      const url = await generateAIImage(prompt, selectedQuality);
      const newMedia: GeneratedMedia = {
        id: Date.now().toString(),
        type: 'image',
        url,
        prompt,
        timestamp: new Date()
      };
      setHistory(prev => [newMedia, ...prev]);
      setPrompt('');
    } catch (error: any) {
      console.error(error);
      alert("Neural Synthesis disrupted. Try a different visualization prompt! 🎨");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-zinc-950 p-6 md:p-10 custom-scrollbar overflow-y-auto">
      <div className="max-w-6xl mx-auto w-full space-y-12">
        <header className="space-y-4 text-center md:text-left">
          <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight">
            Neural <span className="gradient-text">Synthesis Lab</span>
          </h1>
          <p className="text-zinc-500 text-sm font-bold uppercase tracking-[0.3em]">
            High-Speed Visual Generation Engine
          </p>
        </header>

        <section className="glass rounded-[40px] p-2 md:p-3 shadow-2xl border-white/5">
          <form onSubmit={handleGenerate} className="flex flex-col md:flex-row gap-2">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Visual directive: A cyberpunk city in rain..."
              className="flex-1 bg-transparent px-6 py-4 text-white focus:outline-none placeholder-zinc-700 text-lg"
            />
            <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-3xl border border-white/5">
              {(['1K', '2K'] as const).map(q => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setSelectedQuality(q)}
                  className={`px-5 py-2 rounded-2xl text-xs font-black transition-all uppercase tracking-widest ${
                    selectedQuality === q ? 'bg-white text-black shadow-xl' : 'text-zinc-500 hover:text-white'
                  }`}
                >
                  {q}
                </button>
              ))}
            </div>
            <button
              type="submit"
              disabled={isGenerating || !prompt.trim()}
              className="px-10 py-4 bg-white text-black font-black rounded-[30px] hover:bg-zinc-200 transition-all disabled:opacity-50 flex items-center justify-center gap-3 whitespace-nowrap shadow-xl uppercase text-sm tracking-widest"
            >
              {isGenerating ? (
                <>
                  <i className="fas fa-circle-notch fa-spin"></i> Mapping...
                </>
              ) : (
                <>
                  <i className="fas fa-wand-magic-sparkles"></i> Synthesize
                </>
              )}
            </button>
          </form>
        </section>

        <div className="space-y-8">
          <div className="flex items-center justify-between border-b border-white/5 pb-4">
            <h3 className="text-xl font-black text-white uppercase tracking-widest">Synthesis Archive</h3>
            <span className="text-zinc-600 text-xs font-bold">{history.length} ITEMS LOGGED</span>
          </div>

          {history.length === 0 ? (
            <div className="py-20 flex flex-col items-center justify-center text-zinc-800 space-y-4">
              <i className="fas fa-palette text-6xl opacity-10"></i>
              <p className="text-sm font-bold uppercase tracking-widest opacity-20">Waiting for Directive</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {history.map(item => (
                <div key={item.id} className="group relative glass rounded-[32px] overflow-hidden transition-all hover:scale-[1.02] shadow-2xl border-white/5 animate-in zoom-in-95 duration-500">
                  <img src={item.url} alt={item.prompt} className="w-full aspect-square object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-all flex flex-col justify-end p-8">
                    <p className="text-white text-sm font-bold italic leading-relaxed mb-6">"{item.prompt}"</p>
                    <div className="flex gap-3">
                      <a 
                        href={item.url} 
                        download={`sclarista-art-${item.id}.png`}
                        className="flex-1 py-3 bg-white text-black rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-zinc-200"
                      >
                        <i className="fas fa-download"></i> Archive
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MediaGenerator;
