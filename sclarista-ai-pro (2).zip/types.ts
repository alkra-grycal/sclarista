
export enum AppMode {
  CHAT = 'CHAT',
  LIVE = 'LIVE',
  UTILITIES = 'UTILITIES',
  SETTINGS = 'SETTINGS'
}

export type ThemeMode = 'DARK' | 'LIGHT';

export interface MessagePart {
  text?: string;
  inlineData?: {
    mimeType: string;
    data: string;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string | MessagePart[];
  timestamp: any;
  groundingMetadata?: any;
  isLoading?: boolean;
}

export interface ChatHistory {
  id: string;
  title: string;
  messages: ChatMessage[];
  lastUpdated: any;
  userId: string;
}

export interface GeneratedMedia {
  id: string;
  type: 'image' | 'video' | 'audio';
  url: string;
  prompt: string;
  timestamp: Date;
}

export interface SceneAnalysisResult {
  items: { name: string; count: number }[];
  description: string;
}
