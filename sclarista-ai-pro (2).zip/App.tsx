
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import ChatInterface from './components/ChatInterface';
import LiveSession from './components/LiveSession';
import Utilities from './components/Utilities';
import Settings from './components/Settings';
import Auth from './components/Auth';
import { AppMode, ThemeMode } from './types';
import { auth, onAuthStateChanged, db } from './services/firebaseService';
import { doc, getDoc, onSnapshot } from 'firebase/firestore';

const App: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const [currentMode, setMode] = useState<AppMode>(AppMode.CHAT);
  const [selectedChatId, setSelectedChatId] = useState<string | undefined>();
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState<ThemeMode>('DARK');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Real-time sync settings including theme
        onSnapshot(doc(db, "settings", currentUser.uid), (doc) => {
          if (doc.exists()) {
            setTheme(doc.data().theme || 'DARK');
          }
        });
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (theme === 'LIGHT') {
      document.body.classList.add('light-mode');
    } else {
      document.body.classList.remove('light-mode');
    }
  }, [theme]);

  const handleModeChange = (mode: AppMode) => {
    if (mode !== AppMode.CHAT) setSelectedChatId(undefined);
    setMode(mode);
  };

  const renderMode = () => {
    switch (currentMode) {
      case AppMode.CHAT:
        return <ChatInterface initialChatId={selectedChatId} theme={theme} />;
      case AppMode.LIVE:
        return <LiveSession theme={theme} />;
      case AppMode.UTILITIES:
        return <Utilities theme={theme} />;
      case AppMode.SETTINGS:
        return <Settings theme={theme} />;
      default:
        return <ChatInterface theme={theme} />;
    }
  };

  if (loading) {
    return (
      <div className={`h-screen w-screen flex items-center justify-center ${theme === 'LIGHT' ? 'bg-zinc-50' : 'bg-zinc-950'}`}>
        <div className="w-16 h-16 border-4 border-purple-500/20 border-t-purple-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) return <Auth />;

  return (
    <div className={`flex h-screen overflow-hidden transition-colors duration-500 ${theme === 'LIGHT' ? 'bg-zinc-50 text-zinc-900 selection:bg-purple-200' : 'bg-zinc-950 text-zinc-100 selection:bg-purple-500/30'}`}>
      <Sidebar currentMode={currentMode} setMode={handleModeChange} theme={theme} />
      <main className="flex-1 relative overflow-hidden">
        {renderMode()}
      </main>
    </div>
  );
};

export default App;
